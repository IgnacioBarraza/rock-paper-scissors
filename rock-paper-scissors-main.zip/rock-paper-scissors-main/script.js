let playerScore = 0
let computerScore = 0
let tie = 0

function computerChoice() {
    let choice = ['rock', 'paper', 'scissors']
    return choice[Math.floor(Math.random() * choice.length)]
}

// console.log(computerChoice);

function playRound(playerSelection, computerSelection) {
    // let computerSelection = computerChoice();
    let result = ""

    if ((playerSelection === 'rock' && computerSelection === 'scissors') ||
        (playerSelection === 'paper' && computerSelection === 'rock') ||
        (playerSelection === 'scissors' && computerSelection === 'paper')) {
        
        playerScore += 1
        result = ('You win!! ' + playerSelection + ' beats ' + computerSelection + '\nPlayer Score: ' + playerScore + '\nComputer Score: ' + computerScore)
    
        if (playerScore === 5) {
            result += 'You won the game, reload the page to play again...'
        }
    }
    else if (playerSelection === computerSelection) {
        result += ('It\'s a tie, both chose: ' + playerSelection)
        tie += 1
    }
    else{
        computerScore += 1

        result = ('You lose!! ' + playerSelection + ' don\'t beat ' + computerSelection 
                    + '\nPlayer Score: ' + playerScore + '\nCpomputer Score: ' +computerScore)
        
        if (computerScore === 5) {
            result += '\nI won the game!!, to lose again reload the page...'
        }
    }
    return result
};



for (let i = 0; i < 5; i++) {
    let playerSelection = prompt('Choose: \nrock\npaper\nscissors')

    const computerSelection = computerChoice()
    alert(playRound(playerSelection, computerSelection));
}

alert('Player Score: ' + playerScore + '\nComputer Score: ' + computerScore + '\nTie Score: ' + tie)